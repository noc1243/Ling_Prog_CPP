#########################################################
#########################################################

!!!TRABALHO DE LINGUAGENS DE PROGRAMAÇÃO - 2016.2!!!

AUTORES: BRUNO MACHADDO AFONSO
	 DIOGO NOCERA MAGALHÃES

PROF: MIGUEL ELIAS MITRE CAMPISTA

#########################################################
#########################################################


1. Tabela de Conteúdos

	2 -> Requerimentos
	3 -> Como Instalar e Iniciar o Software
	4 -> Informações Gerais

-------------------------------------------------------------------------------------------------

2. Requerimentos


###	C++11 (ISO)
###	Perl v5
###	make

-------------------------------------------------------------------------------------------------

3. Como Instalar e Iniciar o Software


	3.1 - Descomprima o arquivo "LINGPROG_BRUNO_E_DIOGO.zip"

	3.2 - Dentro da pasta criada, execute o comando "make" (caso seja necessário recompilar o software, execute o comando "make clean"). Será criada uma pasta contendo os arquivos e divisões do trabalho (códigos, bibliotecas e executável) chamada "~/Trab_LingProg_2016-2_Bruno-e-Diogo_Perl+Cpp"

	3.3 - Para iniciar o software, entre na pasta "~/Trab_LingProg_2016-2_Bruno-e-Diogo_Perl+Cpp/bin" e execute "./main"

-------------------------------------------------------------------------------------------------

4. Informações Gerais


--- O Software já vem com 2 posts inseridos dentro do "Tópico_A" e 3 usuários dentro de "Users"

--- Caso seja necessáio realizar o login de um usuário criado pelo próprio software, segue a relação de logins e senhas.

Login: Felipe
Senha: cash_master

Login: Pedro
Senha: asdf

Login: Carlos
Senha: 1234

-------------------------------------------------------------------------------------------------

