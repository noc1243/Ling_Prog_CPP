/*
 * Hello.cpp
 *
 *  Created on: 28 de nov de 2016
 *      Author: nocera
 */
 
#include <EXTERN.h>
#include <perl.h>
#include <XSUB.h>
 
#include <iostream>
#include <string>
#include <stdio.h>
#include <fstream>
#include <stdlib.h>
#include <sstream>
#include <vector>
//#include <algorithm>
#include <dirent.h>
#include <string.h>
#include <cstdlib>
#include <cstdio>
#include <sys/types.h>
#include <sys/stat.h>
 
#ifdef _WIN32 || _WIN64
    #define CLEAR "cls"
    #include <conio.h>
#else
    #define CLEAR "clear"
    //#include <ncurses.h>
    #include <termios.h>
    #include <unistd.h>
   
    int getch( ) {
        struct termios oldt,
                     newt;
        int            ch;
        tcgetattr( STDIN_FILENO, &oldt );
        newt = oldt;
        newt.c_lflag &= ~( ICANON | ECHO );
        tcsetattr( STDIN_FILENO, TCSANOW, &newt );
        ch = getchar();
        tcsetattr( STDIN_FILENO, TCSANOW, &oldt );
        return ch;
}
 
#endif
 
//#define ENTER 13
#define ENTER_KEY_DIG 10
 
 
using namespace std;
 
 
EXTERN_C void xs_init (pTHX);
 
EXTERN_C void boot_DynaLoader (pTHX_ CV* cv);
 
EXTERN_C void
xs_init(pTHX)
{
    static const char file[] = __FILE__;
    dXSUB_SYS;
    PERL_UNUSED_CONTEXT;
 
    /* DynaLoader is a special case */
    newXS("DynaLoader::boot_DynaLoader", boot_DynaLoader, file);
}
 
 
PerlInterpreter *my_perl;
 
int validateLogin (char * login, char * senha) {
    dSP;
    ENTER;
    SAVETMPS;
    PUSHMARK(SP);
    XPUSHs(sv_2mortal(newSVpv(login,strlen(login))));
    XPUSHs(sv_2mortal(newSVpv(senha,strlen(senha))));
    PUTBACK;
    call_pv("userHandler::validateLogin", G_SCALAR);
    SPAGAIN;
 
    int resultado = POPi;
    PUTBACK;
    FREETMPS;
    LEAVE;
 
    return resultado;
}
 
int insertUser (char * login, char * senha, char * cpf) {
    dSP;
    ENTER;
    SAVETMPS;
    PUSHMARK(SP);
    XPUSHs(sv_2mortal(newSVpv(login,strlen(login))));
    XPUSHs(sv_2mortal(newSVpv(senha,strlen(senha))));
    XPUSHs(sv_2mortal(newSVpv(cpf,strlen(cpf))));
    PUTBACK;
    call_pv("userHandler::insertUser", G_SCALAR);
    SPAGAIN;
 
    int resultado = POPi;
    PUTBACK;
    FREETMPS;
    LEAVE;
 
    return resultado;
}
 
void searchTopic (char * topic_name) {
    dSP;
    ENTER;
    SAVETMPS;
    PUSHMARK(SP);
    XPUSHs(sv_2mortal(newSVpv(topic_name,strlen(topic_name))));
    PUTBACK;
    call_pv("textReader::searchTopic", G_SCALAR);
    SPAGAIN;
 
    PUTBACK;
    FREETMPS;
    LEAVE;
 
}
 
int createPost (char * nome, char * post_number, char * message, char * topic_name) {
    dSP;
    ENTER;
    SAVETMPS;
    PUSHMARK(SP);
    XPUSHs(sv_2mortal(newSVpv(nome,strlen(nome))));
    XPUSHs(sv_2mortal(newSVpv(post_number,strlen(post_number))));
    XPUSHs(sv_2mortal(newSVpv(message,strlen(message))));
    XPUSHs(sv_2mortal(newSVpv(topic_name,strlen(topic_name))));
    PUTBACK;
    call_pv("userHandler::createPost", G_SCALAR);
    SPAGAIN;
 
    int resultado = POPi;
    PUTBACK;
    FREETMPS;
    LEAVE;
 
    return resultado;
}
 
int deleteUser (char * login) {
    dSP;
    ENTER;
    SAVETMPS;
    PUSHMARK(SP);
    XPUSHs(sv_2mortal(newSVpv(login,strlen(login))));
    PUTBACK;
    call_pv("userHandler::deleteUser", G_SCALAR);
    SPAGAIN;
 
    int resultado = POPi;
    PUTBACK;
    FREETMPS;
    LEAVE;
 
    return resultado;
}
 
void chkAllDirectories () {
    dSP;
    ENTER;
    SAVETMPS;
    PUSHMARK(SP);
    PUTBACK;
    call_pv("filesHandler::chkAllDirectories", G_SCALAR);
    SPAGAIN;
 
    PUTBACK;
    FREETMPS;
    LEAVE;
}
 
void runAllDirectories () {
    dSP;
    ENTER;
    SAVETMPS;
    PUSHMARK(SP);
    PUTBACK;
    call_pv("filesHandler::runAllDirectories", G_SCALAR);
    SPAGAIN;
 
    PUTBACK;
    FREETMPS;
    LEAVE;
}
 
 
class User
{
    public:
    User (const int fileName)
    {
        char buffer [100];
        sprintf (buffer, "../Users/%d.txt", fileName);
 
        int i =0;
        string line;
 
        stringstream ss;
        ss << buffer;
        ss >> this->path;
 
        ifstream file (buffer);
        if (file.is_open())
        {
            while (getline (file, line))
            {
                switch (i)
                {
                    case 0: this->serial = atoi (line.c_str());
                            break;
                    case 1: this->nick = line;
                            break;
                    case 2: this->cryptPassword = line;
                            break;
                    case 3: this->cpf = line;
                            break;
                    case 4: this->priority = atoi (line.c_str());
                            break;
                    case 5: this->flags = atoi (line.c_str());
                            break;
                }
                i++;
            }
        }
    }
 
    User (const User& original): path (original.getPath()), serial (original.getSerial()), nick (original.getName()),
            cryptPassword(original.getCryptPassword()), cpf (original.getCpf()), priority(original.getPriority()), flags(original.getFlags()) {}
 
    User () : path (" ... "), serial (0), nick ("Unknown"), cryptPassword (" ... "), cpf (" ... "), priority (1), flags(0) {}
 
    void showValues ()
    {
        cout << path << endl;
        cout << serial << endl;
        cout << nick << endl;
        cout << cryptPassword << endl;
        cout << cpf << endl;
        cout << priority << endl;
    }
 
    inline string getName ()
    {
        return this->nick;
    }
 
    inline int getSerial ()
    {
        return this->serial;
    }
 
    inline string getCryptPassword ()
    {
        return this->cryptPassword;
    }
 
    inline string getCpf()
    {
        return this->cpf;
    }
 
    inline string getPath ()
    {
        return path;
    }
 
    inline unsigned int getPriority ()
    {
        return priority;
    }
 
    inline unsigned int getFlags ()
    {
        return flags;
    }
 
    inline string getName () const
    {
        return this->nick;
    }
 
    inline int getSerial () const
    {
        return this->serial;
    }
 
    inline string getCryptPassword () const
    {
        return this->cryptPassword;
    }
 
    inline string getCpf() const
    {
        return this->cpf;
    }
 
    inline string getPath ()const
    {
        return path;
    }
 
    inline unsigned int getPriority () const
    {
        return priority;
    }
 
    inline unsigned int getFlags () const
    {
        return flags;
    }
 
    friend ostream& operator<<(ostream& os, const User &user)
    {
        os<< user.nick;
        return os;
    }
 
    friend ostream& operator<<(ostream& os, const User * user)
    {
        if (user)
        {
            os<< user->nick;
        }
        return os;
    }
 
    private:
    string path ;
    int serial;
    string nick;
    string cryptPassword;
    string cpf;
    unsigned int priority;
    unsigned int flags;
};
 
class Post
{
public:
    Post (const char * postName, const int postOrder)
    {
        char buffer [100];
        sprintf (buffer, "../%s/%d.txt", postName, postOrder);
 
        stringstream ss;
        ss << buffer;
        ss >> this->path;
 
        int i =0;
        string line;
 
        ifstream file (buffer);
        if (file.is_open())
        {
            while (getline (file, line))
            {
                switch (i)
                {
                    case 0: this->serial = atoi (line.c_str());
                            break;
                    case 1: searchUser(line);
                            break;
                    case 2: (atoi (line.c_str()) > 0?answer= new Post(postName, atoi(line.c_str())) : answer = NULL);
                            break;
                    case 3: this->text = line;
                            break;
                }
                i++;
            }
        }
 
    }
 
    ~Post ()
    {
        if (answer)
            delete answer;
        if (author)
            delete author;
    }
 
    void showPost ()
    {
        if (answer)
            answer->showPost();
        cout << path << endl;
        cout << serial << endl;
        author->showValues();
        cout << text << endl;
    }
 
    inline string getPath ()
    {
        return path;
    }
 
    inline int getSerial ()
    {
        return serial;
    }
 
    inline User * getAuthor()
    {
        return author;
    }
 
    inline Post * getAnswer ()
    {
        return answer;
    }
 
    inline string getText ()
    {
        return text;
    }
 
    friend ostream &operator<< (ostream &os, const Post &post)
    {
        if (post.answer)
            {
                os << "\n\"" << post.answer << "\"" << endl;
                os << "\t" << post.author << endl;
                os << "\t" << post.text << endl;    
            }
            else
            {
                os << "\n" << post.author << endl;
                os << post.text << endl;    
            }
        return os;
    }
 
    friend ostream &operator<< (ostream &os, const Post *post)
    {
        if (post)
        {
            if (post->answer)
            {
                os << "\n\"" << post->answer << "\"" << endl;
                os << "\t" << post->author << endl;
                os << "\t" << post->text << endl;    
            }
            else
            {
                os << "\n" << post->author << endl;
                os << post->text << endl;    
            }

        }
        return os;
    }
 
 
 
private:
    string path;
    int serial;
    User * author;
    Post * answer;
    string text;
 
    void searchUser (string userName)
    {
        char buffer [100];
        int userIndex = 1;
        int i = 0;
 
        sprintf (buffer, "../Users/%d.txt", userIndex);
 
        ifstream file (buffer);
 
        while (file.is_open())
        {
            string line;
            i = 0;
 
            while (getline (file, line))
            {
                if (i == 1)
                    if (line == userName)
                    {
                        this->author = new User (userIndex);
                        file.close();
                        return;
                    }
                i++;
            }
 
            userIndex++;
            file.close();
 
 
            sprintf (buffer, "../Users/%d.txt", userIndex);
            file.open (buffer);
        }
        this->author = new User();
    }
};
 
 
class Thread
{
public:
    Thread (const char * threadName)
    {
        stringstream ss;
        ss << threadName;
        ss >> this->threadName;
 
        this->loaded = false;
    }
 
    ~Thread ()
    {
        for (unsigned int i = 0; i<posts.size(); i++)
        {
            delete_pointed_to<Post> (posts [i]);
        }
    }
 
    void loadPosts ()
    {
        char path [500];
        int postIndex = 1;
        sprintf (path, "../%s/%d.txt", this->threadName.c_str(), postIndex);
 
        ifstream file (path);
 
        while (file.is_open())
        {
            posts.push_back(new Post (threadName.c_str(), postIndex));
 
            postIndex++;
            file.close();
 
            sprintf (path, "../%s/%d.txt", this->threadName.c_str(), postIndex);
            file.open (path);
        }
        this->loaded = true;
    }
    
    void clearPosts ()
    {
        for (unsigned int i = 0; i<posts.size(); i++)
        {
            delete_pointed_to<Post> (posts [i]);
        }
        posts.clear();
    }
 
    void showThread ()
    {
        if (!posts.size ())
        {
            cout << "Thread inexistente!" << endl ;
        }
        for (unsigned int i = 0; i< posts.size(); i++)
        {
            cout << i << endl;
            posts[i]->showPost();
            cout << endl << endl ;
        }
    }
 
    inline string getThreadName ()
    {
        return threadName;
    }
 
    inline bool getLoaded ()
    {
        return loaded;
    }
 
    friend ostream &operator<< (ostream &os, Thread &thread)
    {
        os<< thread.threadName << endl;
        if (thread.loaded)
            for (unsigned int i=0; i<thread.posts.size(); i++) os<< thread.posts[i];
        return os;
    }
 
    friend ostream &operator<< (ostream &os, Thread *thread)
    {
        if (thread)
        {
            os<< thread->threadName << endl;
            if (thread->loaded)
                for (unsigned int i=0; i<thread->posts.size(); i++) os<< thread->posts[i];
        }
        return os;
    }
 
private:
    string threadName;
    vector <Post *> posts;
    bool loaded;
 
    template <typename T>
    void delete_pointed_to(T* const ptr)
    {
        delete ptr;
    }
 
 
};
 
class Interface
{
public:
    Interface()
    {
        loggedUser = new User();
 
        const char * path = "../";
 
        DIR *dir = opendir (path);
 
        struct dirent *entry = readdir (dir);
 
        while (entry != NULL)
        {
            bool validDirectoryName = true;
            if (entry->d_type == DT_DIR)
            {
                for (int i=0; i<7; i++) if (!strcmp(entry->d_name, forbiddenPaths[i])) validDirectoryName = false;
                if (validDirectoryName)
                    threads.push_back(new Thread (entry->d_name));
            }
 
            entry = readdir(dir);
        }
    }
 
    ~Interface ()
    {
        for (unsigned int i = 0; i<threads.size(); i++)
        {
            delete_pointed_to<Thread> (threads [i]);
        }
        delete loggedUser;
    }
        
        void clearDirectories ()
        {
                for (unsigned int i = 0; i<threads.size(); i++)
        {
            delete_pointed_to<Thread> (threads [i]);
        }
        delete loggedUser;
                threads.clear();
        }
        
        void loadDirectories ()
        {
                const char * path = "../";
 
        DIR *dir = opendir (path);
 
        struct dirent *entry = readdir (dir);
 
        while (entry != NULL)
        {
            bool validDirectoryName = true;
            if (entry->d_type == DT_DIR)
            {
                for (int i=0; i<7; i++) if (!strcmp(entry->d_name, forbiddenPaths[i])) validDirectoryName = false;
                if (validDirectoryName)
                    threads.push_back(new Thread (entry->d_name));
            }
 
            entry = readdir(dir);
        }
        }
 
    void showThreads ()
    {
        for (unsigned int i=0; i<threads.size(); i++)
        {
            cout << i << endl;
            cout << threads[i]->getThreadName() << endl;
        }
    }
 
    inline bool getNeedOption()
    {
        return needOption;
    }
 
    inline void setNeedOption (bool needOption)
    {
        this->needOption = needOption;
    }
 
    void loadThread (string threadName)
    {
        for (unsigned int i=0; i<threads.size(); i++)
        {
            if (threads[i]->getThreadName() == threadName)
            {
                threads[i]->loadPosts();
                return;
            }
        }
        cout << "Thread nao encontrada" << endl;
    }
 
    void showLoadedThreads ()
    {
        for (unsigned int i=0; i<threads.size(); i++)
        {
            if (threads[i]->getLoaded())
                cout << threads[i];
        }
    }
 
    friend ostream &operator<< (ostream &os, Interface &interface)
    {
        for (unsigned int i=0; i<interface.threads.size(); i++) os << interface.threads[i];
        return os;
    }
 
    void showMenu ()
    {
        switch (menuState)
        {
            case 1: cout << menu1;
                    break;
            case 2: this->showLoadedThreads();
                    cout << endl;
                    cout << menu2;
                    break;
            case 3: this->needOption = false;
                    break;
            case 4: switch (loggedUser->getPriority())
                    {
                        case 0 :cout << menu4a;
                                break;
                        case 1 :cout << menu4b;
                                break;
                    }
                    break;
        }
    }
 
    void interpreteMenu (unsigned int option)
    {
        string subOption;
        unsigned int response = 0;
        string name;
        char password [20];
                char cpf [20];
        unsigned int index = 0;
        string strResponse;
                char buffer[200];
        switch (menuState)
        {
            case 1 :switch (option)
                    {
                        case 1: cout << *this << endl;
                                cout << "Digite o Topico que quer entrar" << endl;
                                getch();
                                getline(cin, subOption);
                                this->loadThread (subOption);
                                this->menuState = 2;
                                break;
                        case 2: this->menuState = 3;
                                break;
                        case 3: this->menuState = 4;
                                break;
                                                case 4: cout <<"Digite o Topico a ser pesquisado: " << endl;
                                                                getch();
                                                                getline(cin, subOption);
                                                                searchTopic((char *) subOption.c_str());
                                                                cout << "Digite o Topico que quer entrar" << endl;
                                                                getline(cin, subOption);
                                this->loadThread (subOption);
                                this->menuState = 2;
                                                                break;
                                                case 5: cout << "Login: ";
                                                                getch();
                                                                getline(cin, name);
                                                                cout << "Password: ";
                                                                password[index] = getch ();
                                                                while ((int)password[index] != ENTER_KEY_DIG && index <20)
                                                                {
                                                                        index ++;
                                                                        password[index] = getch();
                                                                }
                                                                password[index] = '\0';
                                                                cout << endl <<"Cpf: ";
                                                                cin >> cpf;
                                                                this->menuState = 1;
                                                                if (!insertUser((char *)name.c_str(), password, cpf)) {
                                                                        searchUser(name);
                                                                        loggedUser->showValues();
                                                                }
                                                                getch();
                                                                break;
                    }
                    break;
            case 2:switch (option)
                   {
                    case 1: cout << "Digite o texto do Post\n";
                            getch();
                            getline(cin, subOption);
                            for (unsigned int i=0; i<threads.size(); i++)
                            {
                                if (threads[i]->getLoaded())
                                {
                                    createPost ((char *) this->loggedUser->getName().c_str(), "0",(char *) subOption.c_str(),(char *) threads[i]->getThreadName().c_str());
                                    threads[i]->clearPosts();
                                    threads[i]->loadPosts();
                                }
                            }
                            break;
                    case 2: cout << "Digite o texto do Post\n";
                            getch();
                            getline(cin, subOption);
                            cout << "Digite qual Post sera respondido\n";
                            cin >> response;
                            strResponse = to_string (response);
                            for (unsigned int i=0; i<threads.size(); i++)
                            {
                                if (threads[i]->getLoaded())
                                {
                                    createPost ((char *) this->loggedUser->getName().c_str(), (char *) strResponse.c_str(),(char *) subOption.c_str(),(char *) threads[i]->getThreadName().c_str());
                                    threads[i]->clearPosts();
                                    threads[i]->loadPosts();
                                }
                            }
                            break;
                    case 3: menuState = 1;
                            for (unsigned int i=0; i<threads.size(); i++)
                            {
                                if (threads[i]->getLoaded())
                                {
                                    threads[i]->clearPosts();
                                }
                            }
                            break;
                   }
                   break;
            case 3: cout << "Login: ";
                    getch();
                    getline(cin,name);
                    cout << "Password: ";
                    password[index] = getch ();
                    while ((int)password[index] != ENTER_KEY_DIG && index <20)
                    {
                        index ++;
                        password[index] = getch();
                    }
                    password[index] = '\0';
                    this->menuState = 1;
                    if (!validateLogin((char *)name.c_str(), password)) {
                        searchUser(name);
                    }
                    getch();
                    break;
            case 4:switch (loggedUser->getPriority())
                   {
                        case 0: switch (option)
                                {
                                    case 1: cout << "Digite o Nome do Usuario a ser apagado" << endl;
                                                                                        getch();
                                                                                        getline(cin, subOption);
                                                                                        deleteUser((char *) subOption.c_str());
                                            break;
                                    case 2: cout << "Digite o nome do Topico" << endl;
                                                                                        getch();
                                                                                        getline(cin, subOption);
                                                                                        sprintf (buffer, "../%s", subOption.c_str());
                                                                                        mkdir(buffer, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                                                        cout << "Digite o texto do Post\n";
                                                                                        getline(cin, strResponse);
                                                                                        createPost ((char *) this->loggedUser->getName().c_str(), "0",(char *) strResponse.c_str(),(char *) subOption.c_str());
                                                                                        clearDirectories();
                                                                                        loadDirectories ();
                                            break;
                                    case 3: logout();
                                            menuState = 1;
                                            break;
                                    case 4: chkAllDirectories();
                                            getch();
                                            getch();
                                            break;
                                    case 5: menuState = 1;
                                            break;
                                }
                                break;
                        case 1: switch (option)
                                {
                                    case 1: logout();
                                            menuState = 1;
                                            break;
                                    case 2: menuState = 1;
                                            break;
                                }
                                break;
                   }
                   break;
        }
    }
 
private:
    vector <Thread *> threads;
    User *loggedUser;
    unsigned int menuState = 1;
    const char * forbiddenPaths [7] = {"Debug", "Users", "bin", "lib", ".settings", ".", ".."};
    bool needOption = true;
 
    string menu1 = "Escolha uma entre as opcoes abaixo:\n\
1 - Ver todas as Threads e escolher uma para visualizar\n\
2 - Fazer Login\n\
3 - Opcoes de Conta\n\
4 - Procurar Topico\n\
5 - Registrar Novo Usuario\n\
0 - Sair do Programa\n";
 
 
 //OK!
    string menu2 = "1 - Postar Algo\n\
2 - Responder uma postagem \n\
3 - Sair da thread\n";
 
    string menu4a = "1 - Apagar Usu�rio\n\
2 - Criar Thread\n\
3 - Logout\n\
4 - Procurar Curses\n\
5 - Sair deste menu\n";
 
    string menu4b = "1 - Logout\n\
2 - Sair deste menu\n";
 
 
 
    template <typename T>
    void delete_pointed_to(T* const ptr)
    {
        delete ptr;
    }
 
    void logout ()
    {
        if (this->loggedUser->getName() != "Unknown")
        {
            delete this->loggedUser;
            this->loggedUser = new User ();
        }
        else
            cout << "Voc� n�o est� logado!!\n";
        getch();
        getch();
    }
 
    void searchUser (string userName)
    {
        if (this->loggedUser)
            delete this->loggedUser;
        char buffer [1000];
    
        int i = 0;
 
                
        const char * path = "../Users/";
 
        DIR *dir = opendir (path);
 
        struct dirent *entry = readdir (dir);
 
        while (entry != NULL)
        {
            if (entry->d_type != DT_DIR)
            {
                sprintf (buffer,"../Users/%s", entry->d_name);
                ifstream file (buffer);
                                if (file.is_open())
                                {
                                        string line;
                                        i = 0;
                 
                                        while (getline (file, line))
                                        {
                                                
                                                if (i == 1)
                                                        if (line == userName)
                                                        {
                                                                string ddName (entry->d_name);
                                                                int userIndex = stoi (ddName);
                                                                this->loggedUser = new User (userIndex);
                                                                file.close();
                                                                return;
                                                        }
                                                i++;
                                        }
                 
                                        file.close();
                          }
                 
            }
                        entry = readdir(dir);
        }
    }
 
};
 
int main(int argc, char **argv, char **env) {
 
    char *my_argv[] = { "", "main.pl"};
    PERL_SYS_INIT3 (&argc, &argv, &env);
 
    my_perl = perl_alloc();
    perl_construct(my_perl);
    PL_exit_flags |= PERL_EXIT_DESTRUCT_END;
 
    //perl_parse(my_perl, NULL, 2, my_argv, (char **)NULL);
    perl_parse(my_perl, xs_init, 2, my_argv, (char **)NULL);
    perl_run(my_perl);
 
    unsigned int option = 1;
   User  firstUser(2);
//   cout << firstUser;
//   firstUser.showValues();
//   User testUser;
//   testUser.showValues();
//   Post explodiu ("Topico_B",3);
//   cout << explodiu;
//   explodiu.showPost();
//   Thread firstThread ("Topico_B");
//   firstThread.loadPosts();
//   cout << firstThread;
//   firstThread.showThread();
   Interface interface;
//   cout << interface;
//   interface.showThreads();
//   interface.showLoadedThreads();
//   interface.loadThread ("Topico_A");
//   cout << interface;
   interface.showMenu();
   cin >> option;
   while (option)
   {
       system (CLEAR);
       interface.interpreteMenu(option);
       system (CLEAR);
       interface.showMenu ();
       if (interface.getNeedOption ())
           cin >> option;
       else
           interface.setNeedOption (true);
   }
//   interface.showLoadedThreads();
   return 0;
}